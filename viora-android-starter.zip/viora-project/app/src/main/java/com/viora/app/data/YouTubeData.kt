package com.viora.app.data

import com.viora.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

const val YOUTUBE_READONLY_SCOPE = "https://www.googleapis.com/auth/youtube.readonly"

 data class VideoItem(
    val id: String,
    val title: String,
    val channelTitle: String,
    val description: String,
    val thumbnailUrl: String,
    val publishedAt: String
) {
    val watchUrl: String get() = "https://www.youtube.com/watch?v=$id"
}

data class ChannelItem(
    val id: String,
    val title: String,
    val thumbnailUrl: String
)

data class AccountData(
    val channelTitle: String,
    val channelThumbnail: String,
    val subscriptions: List<ChannelItem>
)

object YouTubeData {
    suspend fun searchVideos(query: String): List<VideoItem> = withContext(Dispatchers.IO) {
        val key = BuildConfig.YOUTUBE_API_KEY
        require(key.isNotBlank() && key != "YOUR_API_KEY") {
            "YouTube API anahtarı ayarlanmamış. README dosyasındaki adımları uygula."
        }
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val url = "https://www.googleapis.com/youtube/v3/search" +
            "?part=snippet&type=video&maxResults=20&q=$encoded&key=$key"
        val json = requestJson(url)
        val items = json.optJSONArray("items") ?: return@withContext emptyList()
        buildList {
            for (index in 0 until items.length()) {
                val item = items.optJSONObject(index) ?: continue
                val id = item.optJSONObject("id")?.optString("videoId").orEmpty()
                val snippet = item.optJSONObject("snippet") ?: continue
                if (id.isBlank() || id == "null") continue
                val thumbnails = snippet.optJSONObject("thumbnails")
                val thumbnail = thumbnails?.optJSONObject("medium")?.optString("url")
                    ?: thumbnails?.optJSONObject("high")?.optString("url")
                    ?: ""
                add(
                    VideoItem(
                        id = id,
                        title = snippet.optString("title", "Başlıksız video"),
                        channelTitle = snippet.optString("channelTitle", "Bilinmeyen kanal"),
                        description = snippet.optString("description", ""),
                        thumbnailUrl = thumbnail,
                        publishedAt = snippet.optString("publishedAt", "")
                    )
                )
            }
        }
    }

    suspend fun loadAccount(accessToken: String): AccountData = withContext(Dispatchers.IO) {
        val channelJson = requestJson(
            "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true&maxResults=1",
            accessToken
        )
        val channelItems = channelJson.optJSONArray("items")
        val channelSnippet = channelItems?.optJSONObject(0)?.optJSONObject("snippet")
            ?: throw IllegalStateException("Bu Google hesabında erişilebilir bir YouTube kanalı bulunamadı.")
        val channelThumbs = channelSnippet.optJSONObject("thumbnails")
        val ownThumbnail = channelThumbs?.optJSONObject("default")?.optString("url").orEmpty()

        val subscriptionsJson = requestJson(
            "https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true&maxResults=50",
            accessToken
        )
        val subscriptionItems = subscriptionsJson.optJSONArray("items")
        val subscriptions = buildList {
            if (subscriptionItems != null) {
                for (index in 0 until subscriptionItems.length()) {
                    val snippet = subscriptionItems.optJSONObject(index)
                        ?.optJSONObject("snippet") ?: continue
                    val resource = snippet.optJSONObject("resourceId")
                    val channelId = resource?.optString("channelId").orEmpty()
                    if (channelId.isBlank()) continue
                    val thumb = snippet.optJSONObject("thumbnails")
                        ?.optJSONObject("default")?.optString("url").orEmpty()
                    add(
                        ChannelItem(
                            id = channelId,
                            title = snippet.optString("title", "Kanal"),
                            thumbnailUrl = thumb
                        )
                    )
                }
            }
        }

        AccountData(
            channelTitle = channelSnippet.optString("title", "YouTube hesabı"),
            channelThumbnail = ownThumbnail,
            subscriptions = subscriptions
        )
    }

    private fun requestJson(url: String, accessToken: String? = null): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("Accept", "application/json")
            if (!accessToken.isNullOrBlank()) {
                setRequestProperty("Authorization", "Bearer $accessToken")
            }
        }

        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val detail = runCatching {
                    JSONObject(body).optJSONObject("error")?.optString("message")
                }.getOrNull().orEmpty()
                throw IllegalStateException(
                    if (detail.isNotBlank()) "YouTube API hatası: $detail" else "İstek başarısız oldu (HTTP $status)."
                )
            }
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }
}
