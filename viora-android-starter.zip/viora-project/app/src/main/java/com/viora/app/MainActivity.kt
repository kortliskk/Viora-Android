package com.viora.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.BookmarkRemove
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.RevokeAccessRequest
import com.google.android.gms.common.api.Scope
import com.viora.app.data.AccountData
import com.viora.app.data.ChannelItem
import com.viora.app.data.SavedVideosStore
import com.viora.app.data.VideoItem
import com.viora.app.data.YouTubeData
import com.viora.app.data.YOUTUBE_READONLY_SCOPE
import kotlinx.coroutines.launch

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Accent = Color(0xFF8B7CFF)
private val Mint = Color(0xFF5DE0C1)
private val Muted = Color(0xFFA8B2C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 16, 32)
        window.navigationBarColor = android.graphics.Color.rgb(11, 16, 32)
        setContent { VioraApp() }
    }
}

private enum class AppTab { SEARCH, SAVED, ACCOUNT }

@Composable
private fun VioraApp() {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()

    var selectedTab by rememberSaveable { mutableStateOf(AppTab.SEARCH) }
    var query by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf(emptyList<VideoItem>()) }
    var saved by remember { mutableStateOf(SavedVideosStore.load(context)) }
    var account by remember { mutableStateOf<AccountData?>(null) }
    var accessToken by remember { mutableStateOf<String?>(null) }
    var isSearching by remember { mutableStateOf(false) }
    var isLoadingAccount by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun acceptAccessToken(token: String) {
        accessToken = token
        isLoadingAccount = true
        message = null
        scope.launch {
            runCatching { YouTubeData.loadAccount(token) }
                .onSuccess {
                    account = it
                    message = "YouTube hesabın bağlandı. Aboneliklerin eşitlendi."
                }
                .onFailure {
                    account = null
                    message = it.message ?: "Hesap bilgileri alınamadı."
                }
            isLoadingAccount = false
        }
    }

    val authorizationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            runCatching {
                Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(result.data!!)
            }.onSuccess { authResult ->
                val token = authResult.accessToken
                if (!token.isNullOrBlank()) acceptAccessToken(token)
                else message = "Google yetkilendirmesi tamamlandı ancak erişim anahtarı alınamadı."
            }.onFailure {
                message = it.message ?: "Google hesabı bağlanamadı."
            }
        }
    }

    fun search() {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) {
            message = "Aramak istediğin konuyu yaz."
            return
        }
        isSearching = true
        message = null
        scope.launch {
            runCatching { YouTubeData.searchVideos(cleanQuery) }
                .onSuccess { results = it }
                .onFailure { message = it.message ?: "Arama yapılamadı." }
            isSearching = false
        }
    }

    fun toggleSaved(video: VideoItem) {
        saved = if (saved.any { it.id == video.id }) {
            saved.filterNot { it.id == video.id }
        } else {
            listOf(video) + saved
        }
        SavedVideosStore.save(context, saved)
    }

    fun openVideo(video: VideoItem) {
        val uri = Uri.parse(video.watchUrl)
        val youtubeIntent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube")
        try {
            context.startActivity(youtubeIntent)
        } catch (_: Exception) {
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                message = "Video açılamadı. YouTube uygulamasını veya tarayıcıyı kontrol et."
            }
        }
    }

    fun connectAccount() {
        val host = activity
        if (host == null) {
            message = "Hesap bağlantısı bu ekranda başlatılamadı."
            return
        }
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope(YOUTUBE_READONLY_SCOPE)))
            .build()
        Identity.getAuthorizationClient(host).authorize(request)
            .addOnSuccessListener { authResult ->
                if (authResult.hasResolution()) {
                    val pendingIntent = authResult.pendingIntent
                    if (pendingIntent != null) {
                        authorizationLauncher.launch(IntentSenderRequest.Builder(pendingIntent).build())
                    } else {
                        message = "Google izin ekranı açılamadı."
                    }
                } else {
                    val token = authResult.accessToken
                    if (!token.isNullOrBlank()) acceptAccessToken(token)
                    else message = "Google hesabından erişim anahtarı alınamadı."
                }
            }
            .addOnFailureListener {
                message = it.localizedMessage ?: "Google hesabı bağlanamadı."
            }
    }

    fun disconnectAccount() {
        val request = RevokeAccessRequest.builder()
            .setScopes(listOf(Scope(YOUTUBE_READONLY_SCOPE)))
            .build()
        Identity.getAuthorizationClient(context).revokeAccess(request)
            .addOnCompleteListener {
                accessToken = null
                account = null
                message = "Google hesabı Viora'dan ayrıldı."
            }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Mint,
            background = Ink,
            surface = Panel,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = { VioraHeader() },
            bottomBar = {
                NavigationBar(
                    containerColor = Panel,
                    contentColor = Color.White,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    NavigationBarItem(
                        selected = selectedTab == AppTab.SEARCH,
                        onClick = { selectedTab = AppTab.SEARCH },
                        icon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                        label = { Text("Keşfet") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == AppTab.SAVED,
                        onClick = { selectedTab = AppTab.SAVED },
                        icon = { Icon(Icons.Outlined.Bookmark, contentDescription = null) },
                        label = { Text("Koleksiyon") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == AppTab.ACCOUNT,
                        onClick = { selectedTab = AppTab.ACCOUNT },
                        icon = { Icon(Icons.Outlined.AccountCircle, contentDescription = null) },
                        label = { Text("Hesap") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                if (!message.isNullOrBlank()) {
                    MessageBanner(message = message!!, onDismiss = { message = null })
                    Spacer(Modifier.height(8.dp))
                }

                when (selectedTab) {
                    AppTab.SEARCH -> SearchScreen(
                        query = query,
                        onQueryChange = { query = it },
                        results = results,
                        savedIds = saved.map { it.id }.toSet(),
                        searching = isSearching,
                        onSearch = { search() },
                        onOpenVideo = { openVideo(it) },
                        onToggleSaved = { toggleSaved(it) }
                    )
                    AppTab.SAVED -> SavedScreen(
                        saved = saved,
                        onOpenVideo = { openVideo(it) },
                        onRemove = { toggleSaved(it) }
                    )
                    AppTab.ACCOUNT -> AccountScreen(
                        account = account,
                        isLoading = isLoadingAccount,
                        isConnected = accessToken != null && account != null,
                        onConnect = { connectAccount() },
                        onDisconnect = { disconnectAccount() },
                        onRefresh = {
                            val token = accessToken
                            if (token != null) acceptAccessToken(token)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun VioraHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Ink)
            .padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Accent),
            contentAlignment = Alignment.Center
        ) {
            Text("V", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("VIORA", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
            Text("Videolarını düzenle, keşfet, kaydet", fontSize = 11.sp, color = Muted)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    results: List<VideoItem>,
    savedIds: Set<String>,
    searching: Boolean,
    onSearch: () -> Unit,
    onOpenVideo: (VideoItem) -> Unit,
    onToggleSaved: (VideoItem) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Ne izlemek istiyorsun?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("YouTube videolarını bul ve kendi listene ekle.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Örn. Kotlin dersleri") },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                shape = RoundedCornerShape(16.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() })
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onSearch,
                enabled = !searching,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (searching) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Icon(Icons.Outlined.Search, contentDescription = "Ara")
            }
        }
        Spacer(Modifier.height(12.dp))
        if (results.isEmpty() && !searching) {
            EmptyPanel(
                title = "Kendi video alanın",
                text = "Bir konu ara. Beğendiğin videoları Koleksiyon bölümüne kaydet; izlemek için YouTube uygulamasını aç."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 18.dp)
            ) {
                items(results, key = { it.id }) { video ->
                    VideoCard(
                        video = video,
                        isSaved = savedIds.contains(video.id),
                        onOpen = { onOpenVideo(video) },
                        onToggleSaved = { onToggleSaved(video) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedScreen(
    saved: List<VideoItem>,
    onOpenVideo: (VideoItem) -> Unit,
    onRemove: (VideoItem) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Koleksiyonun", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Kaydettiğin videolar bu cihazda saklanır.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        if (saved.isEmpty()) {
            EmptyPanel("Henüz kayıt yok", "Keşfet bölümünden videoları kaydettiğinde burada görünür.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                items(saved, key = { it.id }) { video ->
                    VideoCard(video, true, { onOpenVideo(video) }, { onRemove(video) })
                }
            }
        }
    }
}

@Composable
private fun AccountScreen(
    account: AccountData?,
    isLoading: Boolean,
    isConnected: Boolean,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Hesap bağlantısı", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Google hesabını güvenli izin ekranıyla bağla.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (isConnected && account != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (account.channelThumbnail.isNotBlank()) {
                            AsyncImage(
                                model = account.channelThumbnail,
                                contentDescription = "Kanal resmi",
                                modifier = Modifier.size(54.dp).clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(Icons.Outlined.AccountCircle, null, modifier = Modifier.size(54.dp), tint = Accent)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(account.channelTitle, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("YouTube hesabı bağlı", color = Mint, fontSize = 12.sp)
                        }
                    }
                    Divider(color = Color(0xFF303B56))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Abonelikler", fontWeight = FontWeight.SemiBold)
                            Text("Erişilebilen ${account.subscriptions.size} kanal", color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = onRefresh, enabled = !isLoading) {
                            Icon(Icons.Outlined.Sync, contentDescription = "Eşitle", tint = Accent)
                        }
                    }
                    if (account.subscriptions.isEmpty()) {
                        Text("Gösterilecek abonelik bulunamadı.", color = Muted, fontSize = 13.sp)
                    } else {
                        LazyColumn(modifier = Modifier.height(230.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(account.subscriptions, key = { it.id }) { channel -> ChannelRow(channel) }
                        }
                    }
                    Button(
                        onClick = onDisconnect,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A2940)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Google hesabının bağlantısını kes")
                    }
                } else {
                    Icon(Icons.Outlined.AccountCircle, contentDescription = null, tint = Accent, modifier = Modifier.size(52.dp))
                    Text("YouTube hesabını bağla", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Viora, Google'ın kendi izin penceresini açar. Google şifren bu uygulamaya yazılmaz. Sadece YouTube kanalını ve aboneliklerini görüntülemek için salt-okunur izin istenir.",
                        color = Muted,
                        fontSize = 13.sp
                    )
                    Button(
                        onClick = onConnect,
                        enabled = !isLoading,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (isLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Text("Google ile bağlan")
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Not: Bu, YouTube'un resmî uygulaması değildir. Video oynatma, YouTube'un kendi uygulamasında açılır.",
            color = Muted,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun ChannelRow(channel: ChannelItem) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (channel.thumbnailUrl.isNotBlank()) {
            AsyncImage(
                model = channel.thumbnailUrl,
                contentDescription = null,
                modifier = Modifier.size(34.dp).clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF2A3550)), contentAlignment = Alignment.Center) {
                Text(channel.title.take(1).uppercase(), fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(channel.title, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun VideoCard(
    video: VideoItem,
    isSaved: Boolean,
    onOpen: () -> Unit,
    onToggleSaved: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(185.dp)
                    .clickable(onClick = onOpen)
            ) {
                if (video.thumbnailUrl.isNotBlank()) {
                    AsyncImage(
                        model = video.thumbnailUrl,
                        contentDescription = video.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Color(0xFF26324A)))
                }
                Box(
                    Modifier.align(Alignment.Center).size(50.dp).clip(CircleShape).background(Color(0xBB0B1020)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = "YouTube'da aç", tint = Color.White, modifier = Modifier.size(31.dp))
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(video.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(3.dp))
                    Text(video.channelTitle, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = onToggleSaved) {
                    Icon(
                        if (isSaved) Icons.Outlined.BookmarkRemove else Icons.Outlined.BookmarkAdd,
                        contentDescription = if (isSaved) "Koleksiyondan çıkar" else "Koleksiyona ekle",
                        tint = if (isSaved) Mint else Accent
                    )
                }
                IconButton(onClick = onOpen) {
                    Icon(Icons.Outlined.OpenInNew, contentDescription = "YouTube'da aç", tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun EmptyPanel(title: String, text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(text, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun MessageBanner(message: String, onDismiss: () -> Unit) {
    Surface(
        color = Color(0xFF242C45),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onDismiss)
    ) {
        Text(message, modifier = Modifier.padding(12.dp), fontSize = 12.sp, color = Color.White)
    }
}
