package com.viora.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object SavedVideosStore {
    private const val PREFS = "viora_saved_videos"
    private const val KEY_ITEMS = "items"

    fun load(context: Context): List<VideoItem> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    add(
                        VideoItem(
                            id = item.optString("id"),
                            title = item.optString("title"),
                            channelTitle = item.optString("channelTitle"),
                            description = item.optString("description"),
                            thumbnailUrl = item.optString("thumbnailUrl"),
                            publishedAt = item.optString("publishedAt")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, videos: List<VideoItem>) {
        val array = JSONArray()
        videos.forEach { video ->
            array.put(
                JSONObject().apply {
                    put("id", video.id)
                    put("title", video.title)
                    put("channelTitle", video.channelTitle)
                    put("description", video.description)
                    put("thumbnailUrl", video.thumbnailUrl)
                    put("publishedAt", video.publishedAt)
                }
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ITEMS, array.toString())
            .apply()
    }
}
